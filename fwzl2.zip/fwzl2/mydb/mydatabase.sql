/*
Navicat MySQL Data Transfer

Source Server         : mydatabase
Source Server Version : 50622
Source Host           : localhost:3306
Source Database       : database

Target Server Type    : MYSQL
Target Server Version : 50622
File Encoding         : 65001

Date: 2020-03-25 18:41:23
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `information`
-- ----------------------------
DROP TABLE IF EXISTS `information`;
CREATE TABLE `information` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `product_bb` varchar(50) DEFAULT NULL,
  `product_sn` varchar(255) DEFAULT NULL,
  `product_price` decimal(19,4) DEFAULT NULL,
  `product_discount` int(11) DEFAULT NULL,
  `product_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of information
-- ----------------------------
INSERT INTO `information` VALUES ('1', '消防小区', '35', '1室1厅1卫', '3880.0000', '4', '新城');
INSERT INTO `information` VALUES ('2', '新天地广场', '67', '1室1厅2卫', '3550.0000', '4', '回民');
INSERT INTO `information` VALUES ('3', '九田小区', '53', '1室1厅1卫', '3880.0000', '4', '赛罕');
INSERT INTO `information` VALUES ('4', '坤和小区', '55', '1室1厅2卫', '1350.0000', '4', '玉泉');
INSERT INTO `information` VALUES ('5', '北城小区', '45', '3室1厅1卫', '390.0000', '4', '赛罕');
INSERT INTO `information` VALUES ('6', '万达华府', '83', '3室1厅1卫', '580.0000', '4', '回民');
INSERT INTO `information` VALUES ('7', '消防小区', '76', '2室1厅1卫', '5880.0000', '4', '赛罕');
INSERT INTO `information` VALUES ('8', '塞外康居', '78', '2室1厅1卫', '1980.0000', '4', '赛罕');
INSERT INTO `information` VALUES ('9', '石羊小区', '35', '1室1厅2卫', '2980.0000', '4', '回民');
INSERT INTO `information` VALUES ('10', '万达广场', '56', '1室1厅1卫', '1380.0000', '4', '赛罕');
INSERT INTO `information` VALUES ('11', '团结小区', '56', '1室1厅1卫', '990.0000', '4', '赛罕');
INSERT INTO `information` VALUES ('12', '万达广场', '89', '3室1厅1卫', '880.0000', '4', '玉泉');
INSERT INTO `information` VALUES ('13', '水利家属楼', '24', '1室1厅1卫', '2280.0000', '4', '新城');
INSERT INTO `information` VALUES ('14', '团结小区', '76', '1室1厅2卫', '888.0000', '4', '赛罕');
INSERT INTO `information` VALUES ('15', '世纪春天', '78', '1室1厅1卫', '2888.0000', '4', '回民');
INSERT INTO `information` VALUES ('16', '大学东路', '67', '2室1厅2卫', '398.0000', '4', '回民');
INSERT INTO `information` VALUES ('17', '医院家属楼', '55', '1室1厅1卫', '3880.0000', '4', '赛罕');
INSERT INTO `information` VALUES ('18', '博尔顿小区', '67', '1室1厅2卫', '2880.0000', '4', '新城');
INSERT INTO `information` VALUES ('19', '电机场小区', '87', '2室1厅1卫', '760.0000', '4', '赛罕');
INSERT INTO `information` VALUES ('20', '新康小区', '35', '1室1厅1卫', '870.0000', '7', '新城');
INSERT INTO `information` VALUES ('21', '宝塔庄园', '54', '1室1厅1卫', '590.0000', '7', '玉泉');
INSERT INTO `information` VALUES ('22', '富恒家园', '56', '3室1厅2卫', '2680.0000', '7', '回民');
INSERT INTO `information` VALUES ('23', '新华东街', '66', '1室1厅2卫', '7777.0000', '7', '玉泉');
INSERT INTO `information` VALUES ('24', '怡园阳光城', '67', '1室1厅1卫', '880.0000', '7', '回民');
INSERT INTO `information` VALUES ('25', '东银北路', '56', '1室1厅2卫', '888.0000', '7', '回民');
INSERT INTO `information` VALUES ('26', '中伊小区', '68', '2室1厅1卫', '990.0000', '7', '赛罕');
INSERT INTO `information` VALUES ('27', '天河公寓', '70', '2室1厅1卫', '1111.0000', '6', '新城');
INSERT INTO `information` VALUES ('28', '上东国际', '56', '2室1厅1卫', '3333.0000', '6', '赛罕');
INSERT INTO `information` VALUES ('29', '颐和家园', '97', '3室1厅1卫', '3333.0000', '5', '回民');
INSERT INTO `information` VALUES ('79', '水泉文苑', '67', '2室1厅2卫', '3333.0000', '5', '赛罕');

-- ----------------------------
-- Table structure for `message`
-- ----------------------------
DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `m_id` int(11) NOT NULL,
  `memo` varchar(100) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`m_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of message
-- ----------------------------
INSERT INTO `message` VALUES ('7', ' 我来晚了，大家好！ ', '王一', '2020-03-27 11:49:20');
INSERT INTO `message` VALUES ('10', '为什么学历不值钱，但是学区房很值钱？', '张三', '2020-03-27 17:29:37');
INSERT INTO `message` VALUES ('13', '近半数上市公司利润不够买京沪深一套豪宅，\r\n\r\n但卖掉1%的股份就购买几套了！\r\n\r\n请论证楼市，股市哪个泡沫更大？', '王一', '2012-03-27 17:39:26');
INSERT INTO `message` VALUES ('14', '民日报撰文：失去奋斗、房产再多我们也将无家可归！', '张三', '2020-03-27 09:48:48');
INSERT INTO `message` VALUES ('24', '对于自住刚需客来说，真的，少听宏观动态政策走向，九成九和你无关；', '张三', '2020-03-27 23:02:15');
INSERT INTO `message` VALUES ('25', '过往尽成废墟，未来不可知悉，唯有当下教我们万般珍惜。——《吴哥之美》', '王一', '2020-03-27 23:02:47');
INSERT INTO `message` VALUES ('29', '买房确实可以毁掉不少人的理想，但遗憾的是，其实大部分人没有理想，如果是这样的话，买房确实可以当成理想，毕竟他可以让你自律的还房贷，一个自律的人，一生也不会坏到什么地方去；', '张三', '2020-03-27 19:52:35');
INSERT INTO `message` VALUES ('30', '年轻人买房，任何时间点都是合理的，别觉得房子一直在涨，别忘了你也在涨；', '王一', '2020-03-27 19:00:52');
INSERT INTO `message` VALUES ('31', '唯一一个可以贷款30年可以买的东西，我们要珍惜这来之不易的红利；', '张三', '2020-03-27 17:48:29');
INSERT INTO `message` VALUES ('34', '多比较房子，少比较人，幸福啊成长啊都是很私人的东西，房子这个东西拥有了就好，没有高低之分；', '王一', '2020-03-27 19:53:18');
INSERT INTO `message` VALUES ('35', '觉得房子就压得喘不过气的人生，换一样东西照样也会让你窒息；', '张三', '2020-03-27 19:36:01');
INSERT INTO `message` VALUES ('36', '房子是我们人生过程中的一个大坎，但绝对不是唯一一个，这个坎走过了，未来人生路你会发现很多似曾相似的地方；', '王一', '2020-03-27 19:37:16');
INSERT INTO `message` VALUES ('37', '学会赚钱，也要学会花钱，而买房则是我们掌握花钱技能的终极考核；', '张三', '2020-03-26 20:15:58');
INSERT INTO `message` VALUES ('38', '买房，本质上属于扎根，定心后做其他的事情也会比较坚定；', '王一', '2020-03-26 21:14:23');
INSERT INTO `message` VALUES ('39', '买房不是时机问题，能力问题，而是心态问题，对于房子别要的太多这是真的，买错房子的人基本都是又要首付低又要住得近还要面积舒坦点；', '张三', '2020-03-27 17:04:40');
INSERT INTO `message` VALUES ('40', '做所有事情都不是一口气吃成胖子的，工作，谈恋爱，成长，还有买房，都是如此；', '王一', '2020-03-27 17:06:39');
INSERT INTO `message` VALUES ('41', '最后买错房的基本是三类人：纠结的人、要的太多的人、喜欢贪小便宜的人；', '张三', '2020-03-27 18:19:11');
INSERT INTO `message` VALUES ('42', '如果代价一样，千万不要买郊区大房子，一定要选择市中心小房子，一天24小时，不要花3个小时在路上，信不信这3小时就可以决定你的人生；', '王一', '2020-03-27 18:24:57');
INSERT INTO `message` VALUES ('43', '我的前任和我说过，没有什么事物可以给你安全感，安全感是自己给自己的，同样的，房子这个东西也和安全感无关；', '张三', '2020-03-27 18:41:42');
INSERT INTO `message` VALUES ('44', '这个世界终究会对努力的人善意一点，买房也一样。', '王一', '2020-03-27 19:45:04');
INSERT INTO `message` VALUES ('45', '浪漫与庄严的气质，挑高的门厅和气派的大门，圆形的拱窗和转角的石砌，尽显雍容华贵。', '张三', '2020-03-27 22:01:14');
INSERT INTO `message` VALUES ('46', '一进房子，墙上的饰物就吸引了我：不是藏族的宝剑，就是漂亮的纸扇。太漂亮了！', '王一', '2020-03-27 22:07:38');
INSERT INTO `message` VALUES ('47', '金碧辉煌、富丽堂皇；大理石的台阶，名贵的地毯、玉制的石像，一切极尽奢华之至！', '张三', '2020-03-27 22:22:39');
INSERT INTO `message` VALUES ('48', '清新不落俗套，白色灰泥墙结合浅红屋瓦，连续的拱门和回廊，挑高大面窗的客厅，让人心神荡漾。', '王一', '2020-03-27 22:22:46');
INSERT INTO `message` VALUES ('49', '那是一间低矮破旧的南房，屋里终年不见阳光，昏暗潮湿，墙皮早已脱落了，墙上凹凸不平。', '张三', '2020-03-27 22:27:25');
INSERT INTO `message` VALUES ('50', '买房不是时机问题，能力问题，而是心态问题，对于房子别要的太多这是真的，买错房子的人基本都是又要首付低又要住得近还要面积舒坦点；', '王一', '2020-03-27 22:34:30');
INSERT INTO `message` VALUES ('67', '房子是我们人生过程中的一个大坎，但绝对不是唯一一个，这个坎走过了，未来人生路你会发现很多似曾相似的地方；', '张三', '2020-05-02 16:23:33');
INSERT INTO `message` VALUES ('68', '对于自住刚需客来说，真的，少听宏观动态政策走向，九成九和你无关；', '王一', '2020-05-02 16:24:16');
INSERT INTO `message` VALUES ('71', '年轻人买房，任何时间点都是合理的，别觉得房子一直在涨，别忘了你也在涨；', '张三', '2020-05-03 22:16:43');

-- ----------------------------
-- Table structure for `shop_cart`
-- ----------------------------
DROP TABLE IF EXISTS `shop_cart`;
CREATE TABLE `shop_cart` (
  `cart_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`cart_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of shop_cart
-- ----------------------------

-- ----------------------------
-- Table structure for `shop_order`
-- ----------------------------
DROP TABLE IF EXISTS `shop_order`;
CREATE TABLE `shop_order` (
  `sub_id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `order_time` datetime DEFAULT NULL,
  `sum` decimal(19,4) DEFAULT NULL,
  `order_condition` varchar(255) DEFAULT NULL,
  `postway` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of shop_order
-- ----------------------------
INSERT INTO `shop_order` VALUES ('112', '王一', '27', '3', '2019-04-28 20:57:51', '3333.0000', '已付款', '银行卡转账', '天河公寓');
INSERT INTO `shop_order` VALUES ('113', '张三', '17', '3', '2019-04-28 21:01:13', '11640.0000', '已付款', '银行卡转账', '医院家属楼');
INSERT INTO `shop_order` VALUES ('114', '王一', '3', '2', '2019-04-28 21:01:13', '7760.0000', '已付款', '银行卡转账', '九田小区');
INSERT INTO `shop_order` VALUES ('115', '王一', '14', '2', '2019-04-28 21:30:38', '1776.0000', '已付款', '银行卡转账', '团结小区');
INSERT INTO `shop_order` VALUES ('116', '张三', '1', '2', '2019-05-02 17:58:42', '7760.0000', '已付款', '现金支付', '消防小区');
INSERT INTO `shop_order` VALUES ('117', '张三', '23', '1', '2019-05-02 17:59:16', '7777.0000', '已付款', '银行卡转账', '亚龙湾');
INSERT INTO `shop_order` VALUES ('118', '王一', '16', '1', '2019-05-02 20:51:11', '398.0000', '已付款', '银行卡转账', '大学东路');
INSERT INTO `shop_order` VALUES ('119', '张三', '2', '1', '2019-05-02 20:51:34', '3550.0000', '已付款', '现金支付', '新天地广场');
INSERT INTO `shop_order` VALUES ('120', '张三', '12', '1', '2019-05-02 22:51:59', '880.0000', '已付款', '现金支付', '万达广场');
INSERT INTO `shop_order` VALUES ('121', '张三', '23', '1', '2019-05-02 22:51:59', '7777.0000', '已付款', '现金支付', '新华东街');
INSERT INTO `shop_order` VALUES ('122', '王一', '79', '1', '2019-05-02 22:52:29', '3333.0000', '已付款', '银行卡转账', '水泉文苑');
INSERT INTO `shop_order` VALUES ('123', '王一', '28', '1', '2019-05-02 22:52:29', '3333.0000', '已付款', '银行卡转账', '上东国际');
INSERT INTO `shop_order` VALUES ('124', '张三', '24', '1', '2019-05-02 22:53:22', '880.0000', '已付款', '银行卡转账', '怡园阳光城');
INSERT INTO `shop_order` VALUES ('125', '张三', '25', '1', '2019-05-02 22:53:24', '888.0000', '已评价', '现金支付', '东银北路');
INSERT INTO `shop_order` VALUES ('127', '王一', '19', '1', '2019-05-03 15:06:55', '760.0000', '已付款', '银行卡转账', '电机场小区');
INSERT INTO `shop_order` VALUES ('128', '张三', '15', '3', '2019-05-03 15:07:43', '8664.0000', '已付款', '银行卡转账', '世纪春天');
INSERT INTO `shop_order` VALUES ('129', '王一', '29', '2', '2019-05-03 15:29:51', '6666.0000', '已付款', '现金支付', '颐和家园');
INSERT INTO `shop_order` VALUES ('130', '张三', '11', '2', '2019-05-03 15:30:38', '1980.0000', '已付款', '现金支付', '团结小区');
INSERT INTO `shop_order` VALUES ('131', '王一', '22', '2', '2019-05-03 22:04:16', '5360.0000', '已付款', '现金支付', '富恒家园');
INSERT INTO `shop_order` VALUES ('132', '张三', '20', '1', '2019-05-03 22:05:16', '870.0000', '已付款', '银行卡转账', '新康小区');
INSERT INTO `shop_order` VALUES ('133', '王一', '9', '1', '2019-05-03 22:07:21', '2980.0000', '已付款', '银行卡转账', '石羊小区');
INSERT INTO `shop_order` VALUES ('134', '王一', '26', '1', '2019-05-03 22:08:22', '990.0000', '已付款', '银行卡转账', '中伊小区');
INSERT INTO `shop_order` VALUES ('135', '王一', '21', '1', '2019-05-03 22:16:00', '590.0000', '已付款', '现金支付', '分界洲岛');
INSERT INTO `shop_order` VALUES ('136', '张三', '5', '3', '2019-05-03 22:24:38', '1170.0000', '已付款', '银行卡转账', '北城小区');
INSERT INTO `shop_order` VALUES ('137', '张三', '18', '1', '2019-05-03 22:27:54', '2880.0000', '已付款', '现金支付', '博尔顿小区');
INSERT INTO `shop_order` VALUES ('138', '王一', '6', '5', '2019-05-03 22:37:18', '2900.0000', '已付款', '银行卡转账', '万达华府');
INSERT INTO `shop_order` VALUES ('139', '张三', '28', '3', '2019-05-03 22:38:10', '29997.0000', '已付款', '银行卡转账', '香格里拉');
INSERT INTO `shop_order` VALUES ('140', '张三', '13', '3', '2019-05-03 22:56:26', '75240.0000', '已付款', '银行卡转账', '水利家属楼');
INSERT INTO `shop_order` VALUES ('141', '王一', '7', '2', '2019-05-04 16:28:57', '11760.0000', '已付款', '银行卡转账', '消防小区');
INSERT INTO `shop_order` VALUES ('142', '张三', '10', '1', '2019-05-04 21:45:05', '1380.0000', '已付款', '银行卡转账', '万达广场');
INSERT INTO `shop_order` VALUES ('143', '王一', '4', '1', '2019-05-04 21:46:02', '1350.0000', '已付款', '银行卡转账', '坤和小区');
INSERT INTO `shop_order` VALUES ('144', '张三', '21', '4', '2019-05-04 22:32:25', '2360.0000', '已付款', '银行卡转账', '宝塔庄园');
INSERT INTO `shop_order` VALUES ('145', '王一', '8', '1', '2019-05-05 11:01:40', '1980.0000', '已付款', '银行卡转账', '塞外康居');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `sex` varchar(20) DEFAULT NULL,
  `birthday` datetime DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `addr` varchar(50) DEFAULT NULL,
  `weixin` varchar(20) DEFAULT NULL,
  `actor` varchar(5) DEFAULT NULL,
  `question` varchar(20) DEFAULT NULL,
  `answer` varchar(20) DEFAULT NULL,
  `u_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', '马鑫', '女', '2020-01-06 00:00:00', 'mx', '00000000', '内蒙古', '26413912', 'admin', '你是谁', 'zm', '马鑫');
INSERT INTO `user` VALUES ('2', '高鸿媛', '女', '2020-01-07 00:00:00', 'ghy', '15661000', '河北', '111111111', 'user', '密码是', '234', '高鸿媛');
INSERT INTO `user` VALUES ('12', '王一', '女', '2020-01-08 00:00:00', 'ree33', '15771300', '太原', '36136512', 'user', '电话是', '345', '王一');
INSERT INTO `user` VALUES ('13', '王二', '女', '2020-01-09 00:00:00', 'we', '15771911', '通辽', '36136811', 'admin', '为什么', '456', '王二');
INSERT INTO `user` VALUES ('46', '李一', '男', '2020-01-10 00:00:00', 'zy123', '13324611', '内蒙古', 'gt5656312', 'admin', '123', '456', '李一');
INSERT INTO `user` VALUES ('47', '李二', '男', '2020-01-11 00:00:00', 'zb123', '13325622', '吉林', '36136823', 'admin', '456', '453', '李二');
INSERT INTO `user` VALUES ('60', '张三', '女', '1998-01-07 00:00:00', 'zs', '1234', '乌海', 'ajs123', 'user', '你是', '张三', '张三');
